import React from 'react';
import classes from './NewPost.module.scss';
import userImage from '../../assets/MichaelScott.png';
import styled from 'styled-components';
import { MdPhoto, MdGif } from 'react-icons/md';
import { FaAlignLeft, FaRegSmile } from 'react-icons/fa';
import { IoIosAddCircleOutline } from 'react-icons/io';
import { connect } from 'react-redux';
import * as actionTypes from '../../store/actions/actions';

const NewPost = props => {
  const textAreaHeightHandler = e => {
    const element = e.target;
    if (element.value === '') {
      element.style.height = '4rem';
    } else {
      element.style.height = `${element.scrollHeight}px`;
    }
  };
  const Div = styled.div`
    color: ${props =>
      props.bottom ? props.theme.color : props.theme.textPrimary};
  `;
  const Button = styled.button`
    color: #fff;
    background-color: ${({ theme }) => theme.color};
    border: none;
    outline: none;
    padding: 1rem 1.5rem;
    border-radius: 3rem;
    font-weight: 700;
    font-size: 1.6rem;
    cursor: pointer;
    margin-left: 0.8rem;
    &:disabled {
      opacity: 0.3;
    }
  `;
  const DivIcons = styled.div`
    padding: 1rem;
    display: flex;
    justify-content: center;
    align-content: center;
    transition: all 0.3s;
    &:hover {
      background-color: ${({ theme }) => theme.hover};
      border-radius: 10rem;
    }
  `;
  let data = null;

  const getTweet = e => {
    data = {
      handle: '@user_2020',
      name: 'user',
      tweet: `${e.target.value}`,
      tweetid: '55',
      userimg: 'https://picsum.photos/58/58?random=55'
    };
  };

  const sendTweet = () => {
    if (data) {
      props.sendTweet(data);
    }
  };

  return (
    <div className={classes.NewPost}>
      <div className={classes.NewPost_Image}>
        <img src={userImage} alt="user" />
      </div>
      <Div className={classes.NewPost_Right}>
        <textarea
          onChange={e => getTweet(e)}
          className={classes.NewPost_Right_TextArea}
          placeholder="What's happening?"
          onInput={textAreaHeightHandler}
        ></textarea>
        <Div bottom className={classes.NewPost_Right_Bottom}>
          <div className={classes.NewPost_Right_Bottom_Left}>
            <DivIcons className="">
              <MdPhoto />
            </DivIcons>
            <DivIcons>
              <MdGif className={classes.Gif} />
            </DivIcons>
            <DivIcons className="">
              <FaAlignLeft />
            </DivIcons>
            <DivIcons className="">
              <FaRegSmile />
            </DivIcons>
          </div>
          <div className={classes.NewPost_Right_Bottom_Right}>
            <IoIosAddCircleOutline style={{ fontSize: '3.5rem' }} />
            <Button type="button" onClick={sendTweet}>
              Tweet
            </Button>
          </div>
        </Div>
      </Div>
    </div>
  );
};

const mapStateToProps = state => {
  return {
    tweets: state.tweets.tweets
  };
};
const mapDispatchToProps = dispatch => {
  return {
    sendTweet: data => dispatch(actionTypes.sendTweetStart(data))
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(NewPost);
