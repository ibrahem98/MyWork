import React, { useEffect } from 'react';
import Layout from './hoc/Layout/Layout';
import * as actionTypes from './store/actions/actions';
import './App.css';
import { ThemeProvider } from 'styled-components';
import { themes } from './styledComponents/themes';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import Home from './container/Home/Home';
import { connect } from 'react-redux';
import { PhotoModal } from './component/PhotoModal/PhotoModal';
import { Notifications } from './container/Notifications/Notifications';
import { NotFound } from './container/NotFound/NotFound';
import { RedirectToHome } from './component/Redirect/Redirect';
function App(props) {
  const getTweets = props.getTweets;
  useEffect(() => {
    getTweets();
  }, [getTweets]);
  return (
    <BrowserRouter basename="/twitter-clone">
      <Switch>
        <ThemeProvider
          theme={{ ...themes[props.background], ...themes[props.color] }}
        >
          <div className="App">
            <Layout>
              <Switch>
                <Route exact path="/">
                  <RedirectToHome />
                </Route>
                <Route path="/home">
                  <Home />
                </Route>
                <Route path="/notifications">
                  <Notifications />
                </Route>
                <Route path="/photo/:id">
                  <PhotoModal />
                </Route>
                <Route>
                  <NotFound />
                </Route>
              </Switch>
            </Layout>
          </div>
        </ThemeProvider>
      </Switch>
    </BrowserRouter>
  );
}

const mapStateToProps = state => {
  return {
    background: state.themes.background,
    color: state.themes.color
  };
};

const mapDispatchToProps = dispatch => {
  return {
    getTweets: () => dispatch(actionTypes.getTweetsStart())
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(App);
