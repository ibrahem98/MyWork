export const CHANGE_BACKGROUND = 'CHANGE_BACKGROUND';
export const CHANGE_COLOR = 'CHANGE_COLOR';

export const GET_TWEETS_START = 'GET_TWEETS_START';
export const GET_TWEETS = 'GET_TWEETS';
export const GET_TWEETS_DONE = 'GET_TWEETS_DONE';

export const SEND_TWEET_START = 'SEND_TWEET_START';
export const SEND_TWEET = 'SEND_TWEET';
export const SEND_TWEET_DONE = 'SEND_TWEET_DONE';

export const changeBackground = background => {
  localStorage.setItem('background', background);
  return {
    type: CHANGE_BACKGROUND,
    background: background
  };
};

export const changeColor = color => {
  localStorage.setItem('color', color);
  return {
    type: CHANGE_COLOR,
    color: color
  };
};

export const getTweetsStart = () => {
  return {
    type: GET_TWEETS_START
  };
};

export const getTweets = () => {
  return {
    type: GET_TWEETS
  };
};

export const getTweetsDone = data => {
  return {
    type: GET_TWEETS_DONE,
    data: data
  };
};

export const sendTweetStart = data => {
  return {
    type: SEND_TWEET_START,
    data: data
  };
};

export const sendTweet = data => {
  return {
    type: SEND_TWEET,
    data: data
  };
};

export const sendTweetDone = data => {
  return {
    type: SEND_TWEET_DONE,
    data: data
  };
};
