import axios from 'axios';
import { put, takeEvery } from 'redux-saga/effects';
import * as actionTypes from '../actions/actions';

export function* getTweetsSaga() {
  try {
    yield put(actionTypes.getTweets());
    const response = yield axios.get(
      'https://twitter-clone-36440.firebaseio.com/tweets.json'
    );
    yield put(actionTypes.getTweetsDone(response.data));
  } catch (e) {
    console.log(e);
  }
}

export function* sendTweetSaga(action) {
  try {
    yield put(actionTypes.sendTweet());
    yield axios.post(
      'https://twitter-clone-36440.firebaseio.com/tweets.json',
      action.data
    );
    yield put(actionTypes.sendTweetDone());
  } catch (e) {
    console.log(e);
  }
}

export function* watchTweets() {
  yield takeEvery(actionTypes.GET_TWEETS_START, getTweetsSaga);
  yield takeEvery(actionTypes.SEND_TWEET_START, sendTweetSaga);
}
