import React from 'react';
import classes from './Home.module.scss';
import { connect } from 'react-redux';
import { NavLink } from 'react-router-dom';
import { WiStars } from 'react-icons/wi';
import styled from 'styled-components';
import NewPost from '../../component/NewPost/NewPost';
import Tweet from '../../component/Tweet/Tweet';
import userImage from '../../assets/MichaelScott.png';

import TweetPreview from '../../component/TweetPreview/TweetPreview';
import uniqid from 'uniqid';
const Home = props => {
  const P = styled.p`
    color: ${({ theme }) => theme.textPrimary};
    font-family: 'Roboto';
    font-weight: 900;
  `;
  const Div = styled.div`
    color: ${({ theme }) => theme.color};
  `;

  let render = null;

  render = Object.values(props.tweets).map(i => {
    return (
      <React.Fragment key={uniqid()}>
        <Tweet
          tweetid={uniqid()}
          userimg={i.userimg}
          name={i.name}
          handle={i.handle}
          tweet={i.tweet}
          tweetimg={i.tweetimg}
        />
        <Tweet userimg={userImage} name={'michael'} handle={'Michael_scott'}>
          <TweetPreview
            tweetid={10}
            userimg={userImage}
            name={'michael'}
            handle={'Michael_scott'}
          >
            center Lorem, ipsum dolor sit amet consectetur adipisicing elit.
            Dolores reiciendis voluptatum quo ipsa necessitatibus qui rem
          </TweetPreview>
        </Tweet>
      </React.Fragment>
    );
  });

  return (
    <React.Fragment>
      {props.loading ? (
        <div className={classes.spinner}>
          <div className={classes.ldsRing}>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
          </div>
        </div>
      ) : (
        <div className={classes.Home}>
          <Div className={classes.Home_Header}>
            <NavLink to="/home">
              <P>Home</P>
            </NavLink>
            <WiStars />
          </Div>
          <div className={classes.Border}></div>
          <NewPost />
          <Tweet
            userimg={userImage}
            name={'michael'}
            handle={'Michael_scott'}
            tweet={`welcome to twitter clone!, for more information please visit help
        center `}
          />
          {render}
        </div>
      )}
    </React.Fragment>
  );
};

const mapStateToProps = state => {
  return {
    tweets: state.tweets.tweets,
    loading: state.tweets.loading
  };
};

export default connect(mapStateToProps)(Home);
