import React from 'react';
import classes from './Notfound.module.scss';
import styled from 'styled-components';
import { Link } from 'react-router-dom';

export const NotFound = () => {
  const P = styled.p`
    color: ${props => props.theme.textPrimary};
    font-size: 2rem;
    margin-bottom: 2rem;
  `;
  return (
    <div className={classes.NotFound}>
      <P>ooooooops ! Can't find this page</P>

      <Link to="/home">return to home</Link>
    </div>
  );
};
