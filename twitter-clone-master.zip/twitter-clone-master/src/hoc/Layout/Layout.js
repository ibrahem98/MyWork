import React from 'react';
import classes from './Layout.module.scss';

import styled from 'styled-components';
import Nav from '../../component/Nav/Nav';
import Container from '../../hoc/Container/Container';
import { Route } from 'react-router-dom';
import Display from '../../component/DisplayModal/DisplayModal';
import { Recommnded } from '../../component/Recommnded/Recommnded';

const Layout = props => {
  const Div = styled.div`
    background-color: ${({ theme }) => theme.bgPrimary};
    min-height: 100vh;
  `;

  return (
    <Div className={classes.Layout}>
      <Container>
        <div className={classes.GridLayout}>
          <Route path="/display">
            <Display />
          </Route>
          <Nav />
          <main className={classes.Margin}>
            {props.children}
            <Recommnded />
          </main>
        </div>
      </Container>
    </Div>
  );
};

export default Layout;
